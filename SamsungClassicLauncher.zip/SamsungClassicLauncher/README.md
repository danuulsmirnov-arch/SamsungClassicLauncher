# Classic Phone Launcher (Android 13)

A small Android HOME launcher with a classic feature-phone-inspired menu. It does not change the device's system model/manufacturer and does not conceal that the hardware is a smartphone.

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.6.1 support).
2. Allow Gradle sync and install Android SDK Platform 35.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on the device.
5. Press Home and select **Classic Phone** as the default Home app.

Minimum Android: 8.0 (API 26). Target SDK: 28 for broad launcher compatibility. Designed to run on Android 13.

## Notes
- This is the Android Studio source project, not a precompiled APK.
- The UI imitates a classic keypad-phone menu. On-screen controls are touch controls; physical key events depend on the device hardware.
- Calls open the dialer; messages, contacts, camera, gallery, music and settings are delegated to installed Android apps.
- No SMS, call-log, contacts, microphone, or location permissions are requested by this launcher.
