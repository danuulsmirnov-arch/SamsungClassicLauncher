package ru.classic.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(18, 28, 31)
    private val panel = Color.rgb(35, 51, 55)
    private val pale = Color.rgb(218, 228, 220)
    private val muted = Color.rgb(155, 177, 171)
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var menu: LinearLayout
    private var page = 0
    private val entries = listOf(
        Entry("☎", "Телефон", "dial"), Entry("✉", "Сообщения", "sms"),
        Entry("♟", "Контакты", "contacts"), Entry("▦", "Календарь", "calendar"),
        Entry("◷", "Будильник", "alarm"), Entry("♫", "Музыка", "music"),
        Entry("▣", "Камера", "camera"), Entry("▤", "Галерея", "gallery"),
        Entry("◎", "Интернет", "browser"), Entry("▧", "Файлы", "files"),
        Entry("✎", "Заметки", "notes"), Entry("⚙", "Настройки", "settings")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.BLACK
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 12, 18, 12) }
        val top = TextView(this).apply { text = "CLASSIC PHONE     ▮▮▮   ▰ 100%"; setTextColor(muted); textSize = 12f; gravity = Gravity.CENTER; letterSpacing = .08f }
        root.addView(top, LinearLayout.LayoutParams(-1, 30))
        clock = TextView(this).apply { textSize = 48f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setTextColor(pale); gravity = Gravity.CENTER; setPadding(0, 18, 0, 0) }
        root.addView(clock, LinearLayout.LayoutParams(-1, 78))
        date = TextView(this).apply { textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, 0, 0, 20) }
        root.addView(date, LinearLayout.LayoutParams(-1, 34))
        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(10, 12, 10, 12) }
        val title = TextView(this).apply { text = if (page == 0) "МЕНЮ" else "ПРИЛОЖЕНИЯ"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(pale); gravity = Gravity.CENTER; setPadding(0, 0, 0, 10) }
        screen.addView(title)
        menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        screen.addView(menu, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(screen, LinearLayout.LayoutParams(-1, 0, 1f))
        val soft = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 12, 0, 8) }
        soft.addView(key("Опции") { showOptions() }, LinearLayout.LayoutParams(0, 48, 1f))
        soft.addView(key("Выбрать") { launchSelected() }, LinearLayout.LayoutParams(0, 48, 1f))
        soft.addView(key("Назад") { if (page > 0) { page = 0; render() } else showOptions() }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(soft)
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        nav.addView(key("▲") { move(-1) }, LinearLayout.LayoutParams(0, 44, 1f))
        nav.addView(key("●") { launchSelected() }, LinearLayout.LayoutParams(0, 44, 1f))
        nav.addView(key("▼") { move(1) }, LinearLayout.LayoutParams(0, 44, 1f))
        root.addView(nav)
        setContentView(root)
        updateTime()
        showEntries()
    }

    private var selected = 0
    private fun updateTime() {
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date()).replaceFirstChar { it.uppercase() }
    }
    private fun showEntries() {
        menu.removeAllViews()
        val start = if (selected < 6) 0 else 6
        entries.drop(start).take(6).forEachIndexed { index, item ->
            val actual = start + index
            val row = TextView(this).apply {
                text = "${item.icon}    ${item.name}"
                textSize = 17f
                setTextColor(if (actual == selected) Color.WHITE else pale)
                setPadding(14, 9, 12, 9)
                setBackgroundColor(if (actual == selected) Color.rgb(75, 101, 103) else Color.TRANSPARENT)
                isFocusable = true
                setOnClickListener { selected = actual; showEntries(); if (actual == selected) launchSelected() }
            }
            menu.addView(row, LinearLayout.LayoutParams(-1, 43))
        }
    }
    private fun move(delta: Int) { selected = (selected + delta + entries.size) % entries.size; showEntries() }
    private fun key(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(pale); setBackgroundColor(Color.rgb(48, 67, 70)); setPadding(4, 4, 4, 4); setOnClickListener { action() }
    }
    private fun launchSelected() {
        when (entries[selected].action) {
            "dial" -> safe(Intent(Intent.ACTION_DIAL))
            "sms" -> safe(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
            "contacts" -> safe(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
            "calendar" -> safe(Intent(Intent.ACTION_VIEW).setData(CalendarContract.CONTENT_URI))
            "alarm" -> safe(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            "music" -> safe(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
            "camera" -> safe(Intent("android.media.action.IMAGE_CAPTURE"))
            "gallery" -> safe(Intent(Intent.ACTION_VIEW).setType("image/*"))
            "browser" -> safe(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
            "files" -> safe(Intent(Intent.ACTION_GET_CONTENT).setType("*/*"))
            "notes" -> notes()
            "settings" -> safe(Intent(Settings.ACTION_SETTINGS))
        }
    }
    private fun safe(intent: Intent) { try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Приложение не найдено", Toast.LENGTH_SHORT).show() } }
    private fun notes() {
        val input = EditText(this).apply { hint = "Введите заметку"; setTextColor(Color.WHITE); setHintTextColor(muted) }
        AlertDialog.Builder(this).setTitle("Заметки").setView(input).setPositiveButton("Готово", null).setNegativeButton("Закрыть", null).show()
    }
    private fun showOptions() {
        AlertDialog.Builder(this).setTitle("Classic Phone").setItems(arrayOf("Выбрать приложение по умолчанию", "Системные настройки", "О приложении")) { _, which ->
            when (which) {
                0 -> safe(Intent(Settings.ACTION_HOME_SETTINGS))
                1 -> safe(Intent(Settings.ACTION_SETTINGS))
                2 -> AlertDialog.Builder(this).setMessage("Classic Phone 1.0\nИнтерфейс в стиле классического кнопочного телефона. Приложения запускаются средствами Android.").setPositiveButton("OK", null).show()
            }
        }.show()
    }
    data class Entry(val icon: String, val name: String, val action: String)
}
