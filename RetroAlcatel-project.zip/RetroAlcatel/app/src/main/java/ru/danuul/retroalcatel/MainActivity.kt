package ru.danuul.retroalcatel

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var screen: RetroScreen
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        screen = RetroScreen()
        setContentView(screen)
    }
    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (screen.page != 0) { screen.page = 0; screen.invalidate() } else super.onBackPressed()
    }

    inner class RetroScreen : View(this@MainActivity) {
        var page = 0
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val white = Color.WHITE
        private val names = arrayOf("Вызовы","Контакты","Сообщения","Камера","Музыка","Радио","Файлы","Настройки","Приложения")
        private val glyphs = arrayOf("☎","♟","●","◎","▶","♫","▰","⚙","▦")
        private val colors = intArrayOf(0xff168b25.toInt(),0xff1766aa.toInt(),0xffd99012.toInt(),0xff777777.toInt(),0xff76249c.toInt(),0xffb3265b.toInt(),0xffbd760e.toInt(),0xff454545.toInt(),0xff087c86.toInt())
        private val appRows = mutableListOf<Pair<String,Intent>>()
        private var scroll = 0f
        private var downX = 0f
        private var downY = 0f
        init { isFocusable = true }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat()
            c.drawColor(Color.BLACK)
            drawStatus(c,w)
            if (page == 0) drawHome(c,w,h) else if (page == 3) drawApps(c,w,h) else drawMenu(c,w,h)
            drawSoftKeys(c,w,h)
        }
        private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,align:Paint.Align=Paint.Align.CENTER,color:Int=white,bold:Boolean=false) {
            p.color=color; p.textSize=size; p.textAlign=align
            p.typeface=if(bold) Typeface.create("sans-serif",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL)
            c.drawText(s,x,y,p)
        }
        private fun drawStatus(c:Canvas,w:Float) {
            p.color=white; p.strokeWidth=3.5f; p.style=Paint.Style.STROKE
            for(i in 0..3) c.drawLine(18f+i*8,34f-i*6,18f+i*8,34f,p)
            p.style=Paint.Style.FILL
            text(c,"♫",75f,31f,22f)
            p.style=Paint.Style.STROKE; p.strokeWidth=2.5f
            c.drawRect(w-48,15f,w-19,29f,p); p.style=Paint.Style.FILL
            c.drawRect(w-17,19f,w-14,25f,p); c.drawRect(w-45,18f,w-25,26f,p)
        }
        private fun drawSunset(c:Canvas,w:Float,h:Float) {
            p.shader=LinearGradient(0f,45f,0f,h*.82f,intArrayOf(0xff19192b.toInt(),0xff813d42.toInt(),0xffff792d.toInt(),0xfff6a13a.toInt()),null,Shader.TileMode.CLAMP)
            c.drawRect(0f,45f,w,h,p); p.shader=null
            val sy=h*.69f
            p.color=0xffffd66b.toInt(); c.drawCircle(w*.49f,sy,w*.095f,p)
            p.shader=LinearGradient(0f,sy,0f,h,0xffe96a26.toInt(),0xff151a27.toInt(),Shader.TileMode.CLAMP)
            c.drawRect(0f,sy,w,h,p); p.shader=null
            p.color=0xffffb24a.toInt()
            for(i in 0..5) c.drawRect(w*.46f-i*8,sy+12+i*13,w*.53f+i*9,sy+16+i*13,p)
            p.color=0xff090d17.toInt()
            val path=Path().apply {
                moveTo(0f,h*.83f); lineTo(w*.13f,h*.78f); lineTo(w*.22f,h*.84f)
                lineTo(w*.31f,h*.79f); lineTo(w*.42f,h*.88f); lineTo(w*.55f,h*.84f)
                lineTo(w*.69f,h*.91f); lineTo(w*.81f,h*.78f); lineTo(w,h*.83f)
                lineTo(w,h); lineTo(0f,h); close()
            }
            c.drawPath(path,p)
        }
        private fun drawHome(c:Canvas,w:Float,h:Float) {
            drawSunset(c,w,h)
            text(c,"ALCATEL",w/2,h*.17f,27f,bold=true)
            text(c,"one touch",w/2,h*.205f,20f)
            text(c,SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date()),w/2,h*.43f,72f)
            text(c,SimpleDateFormat("dd.MM.yyyy  EEE",Locale("ru")).format(Date()),w/2,h*.49f,22f)
            text(c,"Морской закат",w/2,h*.59f,18f)
        }
        private fun drawMenu(c:Canvas,w:Float,h:Float) {
            text(c,"Меню",w/2,h*.13f,28f)
            val top=h*.2f; val cellW=w/3f; val cellH=(h*.62f)/3f
            for(i in 0..8) {
                val x=(i%3)*cellW+cellW/2; val y=top+(i/3)*cellH
                p.color=colors[i]; c.drawRoundRect(x-31,y-34,x+31,y+28,11f,11f,p)
                text(c,glyphs[i],x,y+12,34f)
                text(c,names[i],x,y+57,14f)
            }
            text(c,"●  ○  ○",w/2,h*.83f,16f)
        }
        private fun drawApps(c:Canvas,w:Float,h:Float) {
            text(c,"Все приложения",w/2,h*.13f,25f)
            if(appRows.isEmpty()) {
                val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                packageManager.queryIntentActivities(intent,0)
                    .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
                    .forEach {
                        val launch=packageManager.getLaunchIntentForPackage(it.activityInfo.packageName)
                        if(launch!=null) appRows.add(it.loadLabel(packageManager).toString() to launch)
                    }
            }
            val rowH=58f; val start=h*.18f
            appRows.forEachIndexed { i,item ->
                val y=start+i*rowH-scroll
                if(y>start-55 && y<h*.87f) {
                    p.color=0xff171717.toInt(); c.drawRect(8f,y,w-8,y+rowH-1,p)
                    text(c,item.first.take(25),24f,y+37,18f,Paint.Align.LEFT)
                    text(c,"›",w-28,y+37,25f)
                }
            }
        }
        private fun drawSoftKeys(c:Canvas,w:Float,h:Float) {
            p.color=0xff050505.toInt(); c.drawRect(0f,h-55,w,h,p)
            p.color=0xff555555.toInt(); c.drawRect(0f,h-56,w,h-54,p)
            text(c,if(page==0) "Меню" else if(page==3) "Открыть" else "OK",24f,h-18,20f,Paint.Align.LEFT)
            text(c,"Назад",w-24,h-18,20f,Paint.Align.RIGHT)
        }
        override fun onTouchEvent(e:MotionEvent):Boolean {
            val w=width.toFloat(); val h=height.toFloat()
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { downX=e.x; downY=e.y; return true }
                MotionEvent.ACTION_UP -> {
                    val dx=e.x-downX; val dy=e.y-downY
                    if(page==3 && abs(dy)>35) {
                        scroll=(scroll-dy).coerceIn(0f,(appRows.size*58f-height*.65f).coerceAtLeast(0f)); invalidate(); return true
                    }
                    if(page!=3 && abs(dx)>50) { page=if(dx<0) 2 else 1; invalidate(); return true }
                    if(e.y>h-60) {
                        if(e.x<w*.5f) page=if(page==0) 1 else if(page==1) 3 else 1 else page=0
                        invalidate(); return true
                    }
                    if(page==0) { page=1; invalidate(); return true }
                    if(page==3) {
                        val index=((e.y-h*.18f+scroll)/58f).toInt()
                        if(index in appRows.indices) try { startActivity(appRows[index].second) } catch (_:Exception) {}
                    } else {
                        val col=(e.x/(w/3f)).toInt().coerceIn(0,2)
                        val row=((e.y-h*.2f)/((h*.62f)/3f)).toInt().coerceIn(0,2)
                        val i=row*3+col
                        if(i==8) { page=3; invalidate() } else launchItem(i)
                    }
                    return true
                }
            }
            return true
        }
        private fun launchItem(i:Int) {
            try {
                when(i) {
                    0 -> startActivity(Intent(Intent.ACTION_DIAL))
                    1 -> startActivity(Intent(Intent.ACTION_PICK).setType("vnd.android.cursor.dir/contact"))
                    2 -> startActivity(Intent(Intent.ACTION_SENDTO).setData(android.net.Uri.parse("smsto:")))
                    3 -> startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                    4 -> startActivity(Intent(Intent.ACTION_VIEW).setType("audio/*"))
                    5 -> { page=3; invalidate() }
                    6 -> startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*"))
                    7 -> startActivity(Intent(Settings.ACTION_SETTINGS))
                    else -> { page=3; invalidate() }
                }
            } catch (_:Exception) { page=3; invalidate() }
        }
    }
}
